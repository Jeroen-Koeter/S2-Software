bij alle projecten waar je zelf dingen kunt invullen kunnen er alleen maar tekens ingevuld worden die nodig zijn voor het werken van het systeem

dobbelstenen:
dit is een random number generator, je kan kiezen wat het maximale nummer is dat gegenereert word, hoeveel nummers er gegenereert worden, 
of je wil tellen hoevaak een bepaald nummer voorkomt in de serie, het gemiddelde van de gehele serie berekenen en het minimum-, maximum getal bereken.

rekenmachine:
de rekenmachine kan optellen, aftrekken, vermenigvuldigen, delen, worteltrekken en machtsverheffen.

eurodollarconv:
de euro dollar converter is best duidelijk het is gewoon een waarde van euro's omzetten naar een waarde in dollars waarbij je zelf de koers bepaald. 

clicker game:
de clicker game is een spel waarbij telken 9 monsters in buttons spawnen je moet deze zo snel mogelijk dood clicken voordat ze jou dood hebben. 
alle monsters hebben aparte stats, je kunt met goud je damage upgrade of towers kopen. goud krijg je van gedode van monsters. 
je krijgt ook xp van gedode monsters. met xp kun je level up, dit geeft jou 100 hp extra maar het maakt ook de monsters sterker.
