﻿namespace App_Clicker
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.StartKnop = new System.Windows.Forms.Button();
            this.LifeLabel = new System.Windows.Forms.Label();
            this.UpgradeKnop = new System.Windows.Forms.Button();
            this.DamageLabel = new System.Windows.Forms.Label();
            this.Monster1 = new System.Windows.Forms.Button();
            this.Monster2 = new System.Windows.Forms.Button();
            this.Monster3 = new System.Windows.Forms.Button();
            this.Monster4 = new System.Windows.Forms.Button();
            this.Monster5 = new System.Windows.Forms.Button();
            this.Monster6 = new System.Windows.Forms.Button();
            this.Monster7 = new System.Windows.Forms.Button();
            this.Monster8 = new System.Windows.Forms.Button();
            this.Monster9 = new System.Windows.Forms.Button();
            this.GoldLabel = new System.Windows.Forms.Label();
            this.LevelLabel = new System.Windows.Forms.Label();
            this.CostLabel = new System.Windows.Forms.Label();
            this.ExpProgressBar = new System.Windows.Forms.ProgressBar();
            this.XPLabel = new System.Windows.Forms.Label();
            this.LevelupKnop = new System.Windows.Forms.Button();
            this.EXPLabel = new System.Windows.Forms.Label();
            this.ResetButton = new System.Windows.Forms.Button();
            this.PotionButton = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.towerButton = new System.Windows.Forms.Button();
            this.TowerCostLabel = new System.Windows.Forms.Label();
            this.TowerLable = new System.Windows.Forms.Label();
            this.PauseButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // StartKnop
            // 
            this.StartKnop.Location = new System.Drawing.Point(681, 5);
            this.StartKnop.Name = "StartKnop";
            this.StartKnop.Size = new System.Drawing.Size(115, 75);
            this.StartKnop.TabIndex = 0;
            this.StartKnop.Text = "Start ";
            this.StartKnop.UseVisualStyleBackColor = true;
            this.StartKnop.Click += new System.EventHandler(this.StartKnop_Click);
            // 
            // LifeLabel
            // 
            this.LifeLabel.AutoSize = true;
            this.LifeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LifeLabel.Location = new System.Drawing.Point(510, 9);
            this.LifeLabel.Name = "LifeLabel";
            this.LifeLabel.Size = new System.Drawing.Size(112, 29);
            this.LifeLabel.TabIndex = 1;
            this.LifeLabel.Text = "Life: 100";
            // 
            // UpgradeKnop
            // 
            this.UpgradeKnop.Enabled = false;
            this.UpgradeKnop.Location = new System.Drawing.Point(681, 86);
            this.UpgradeKnop.Name = "UpgradeKnop";
            this.UpgradeKnop.Size = new System.Drawing.Size(115, 75);
            this.UpgradeKnop.TabIndex = 2;
            this.UpgradeKnop.Text = "Upgrade Damage";
            this.UpgradeKnop.UseVisualStyleBackColor = true;
            this.UpgradeKnop.Click += new System.EventHandler(this.UpgradeKnop_Click);
            // 
            // DamageLabel
            // 
            this.DamageLabel.AutoSize = true;
            this.DamageLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DamageLabel.Location = new System.Drawing.Point(510, 41);
            this.DamageLabel.Name = "DamageLabel";
            this.DamageLabel.Size = new System.Drawing.Size(138, 29);
            this.DamageLabel.TabIndex = 3;
            this.DamageLabel.Text = "Damage: 1";
            // 
            // Monster1
            // 
            this.Monster1.Enabled = false;
            this.Monster1.Location = new System.Drawing.Point(12, 143);
            this.Monster1.Name = "Monster1";
            this.Monster1.Size = new System.Drawing.Size(115, 75);
            this.Monster1.TabIndex = 4;
            this.Monster1.Text = "1";
            this.Monster1.UseVisualStyleBackColor = true;
            this.Monster1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Monster1_Click);
            // 
            // Monster2
            // 
            this.Monster2.Enabled = false;
            this.Monster2.Location = new System.Drawing.Point(133, 143);
            this.Monster2.Name = "Monster2";
            this.Monster2.Size = new System.Drawing.Size(115, 75);
            this.Monster2.TabIndex = 5;
            this.Monster2.Text = "2";
            this.Monster2.UseVisualStyleBackColor = true;
            this.Monster2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Monster2_Click);
            // 
            // Monster3
            // 
            this.Monster3.Enabled = false;
            this.Monster3.Location = new System.Drawing.Point(254, 143);
            this.Monster3.Name = "Monster3";
            this.Monster3.Size = new System.Drawing.Size(115, 75);
            this.Monster3.TabIndex = 6;
            this.Monster3.Text = "3";
            this.Monster3.UseVisualStyleBackColor = true;
            this.Monster3.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Monster3_Click);
            // 
            // Monster4
            // 
            this.Monster4.Enabled = false;
            this.Monster4.Location = new System.Drawing.Point(12, 224);
            this.Monster4.Name = "Monster4";
            this.Monster4.Size = new System.Drawing.Size(115, 75);
            this.Monster4.TabIndex = 7;
            this.Monster4.Text = "4";
            this.Monster4.UseVisualStyleBackColor = true;
            this.Monster4.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Monster4_Click);
            // 
            // Monster5
            // 
            this.Monster5.Enabled = false;
            this.Monster5.Location = new System.Drawing.Point(133, 224);
            this.Monster5.Name = "Monster5";
            this.Monster5.Size = new System.Drawing.Size(115, 75);
            this.Monster5.TabIndex = 8;
            this.Monster5.Text = "5";
            this.Monster5.UseVisualStyleBackColor = true;
            this.Monster5.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Monster5_Click);
            // 
            // Monster6
            // 
            this.Monster6.Enabled = false;
            this.Monster6.Location = new System.Drawing.Point(254, 224);
            this.Monster6.Name = "Monster6";
            this.Monster6.Size = new System.Drawing.Size(115, 75);
            this.Monster6.TabIndex = 9;
            this.Monster6.Text = "6";
            this.Monster6.UseVisualStyleBackColor = true;
            this.Monster6.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Monster6_Click);
            // 
            // Monster7
            // 
            this.Monster7.Enabled = false;
            this.Monster7.Location = new System.Drawing.Point(12, 305);
            this.Monster7.Name = "Monster7";
            this.Monster7.Size = new System.Drawing.Size(115, 75);
            this.Monster7.TabIndex = 10;
            this.Monster7.Text = "7";
            this.Monster7.UseVisualStyleBackColor = true;
            this.Monster7.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Monster7_Click);
            // 
            // Monster8
            // 
            this.Monster8.Enabled = false;
            this.Monster8.Location = new System.Drawing.Point(133, 305);
            this.Monster8.Name = "Monster8";
            this.Monster8.Size = new System.Drawing.Size(115, 75);
            this.Monster8.TabIndex = 11;
            this.Monster8.Text = "8";
            this.Monster8.UseVisualStyleBackColor = true;
            this.Monster8.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Monster8_Click);
            // 
            // Monster9
            // 
            this.Monster9.Enabled = false;
            this.Monster9.Location = new System.Drawing.Point(254, 305);
            this.Monster9.Name = "Monster9";
            this.Monster9.Size = new System.Drawing.Size(115, 75);
            this.Monster9.TabIndex = 12;
            this.Monster9.Text = "9";
            this.Monster9.UseVisualStyleBackColor = true;
            this.Monster9.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Monster9_Click);
            // 
            // GoldLabel
            // 
            this.GoldLabel.AutoSize = true;
            this.GoldLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GoldLabel.Location = new System.Drawing.Point(510, 70);
            this.GoldLabel.Name = "GoldLabel";
            this.GoldLabel.Size = new System.Drawing.Size(76, 29);
            this.GoldLabel.TabIndex = 13;
            this.GoldLabel.Text = "Gold:";
            // 
            // LevelLabel
            // 
            this.LevelLabel.AutoSize = true;
            this.LevelLabel.Location = new System.Drawing.Point(348, 12);
            this.LevelLabel.Name = "LevelLabel";
            this.LevelLabel.Size = new System.Drawing.Size(63, 20);
            this.LevelLabel.TabIndex = 14;
            this.LevelLabel.Text = "Level: 0";
            // 
            // CostLabel
            // 
            this.CostLabel.AutoSize = true;
            this.CostLabel.Location = new System.Drawing.Point(650, 163);
            this.CostLabel.Name = "CostLabel";
            this.CostLabel.Size = new System.Drawing.Size(113, 20);
            this.CostLabel.TabIndex = 15;
            this.CostLabel.Text = "Upgrade cost: ";
            // 
            // ExpProgressBar
            // 
            this.ExpProgressBar.Location = new System.Drawing.Point(27, 41);
            this.ExpProgressBar.Name = "ExpProgressBar";
            this.ExpProgressBar.Size = new System.Drawing.Size(232, 23);
            this.ExpProgressBar.TabIndex = 16;
            // 
            // XPLabel
            // 
            this.XPLabel.AutoSize = true;
            this.XPLabel.Location = new System.Drawing.Point(23, 9);
            this.XPLabel.Name = "XPLabel";
            this.XPLabel.Size = new System.Drawing.Size(45, 20);
            this.XPLabel.TabIndex = 17;
            this.XPLabel.Text = "EXP:";
            // 
            // LevelupKnop
            // 
            this.LevelupKnop.Enabled = false;
            this.LevelupKnop.Location = new System.Drawing.Point(327, 39);
            this.LevelupKnop.Name = "LevelupKnop";
            this.LevelupKnop.Size = new System.Drawing.Size(99, 48);
            this.LevelupKnop.TabIndex = 18;
            this.LevelupKnop.Text = "Level up";
            this.LevelupKnop.UseVisualStyleBackColor = true;
            this.LevelupKnop.Click += new System.EventHandler(this.LevelupKnop_Click);
            // 
            // EXPLabel
            // 
            this.EXPLabel.AutoSize = true;
            this.EXPLabel.Location = new System.Drawing.Point(23, 67);
            this.EXPLabel.Name = "EXPLabel";
            this.EXPLabel.Size = new System.Drawing.Size(0, 20);
            this.EXPLabel.TabIndex = 19;
            // 
            // ResetButton
            // 
            this.ResetButton.Enabled = false;
            this.ResetButton.Location = new System.Drawing.Point(681, 536);
            this.ResetButton.Name = "ResetButton";
            this.ResetButton.Size = new System.Drawing.Size(115, 75);
            this.ResetButton.TabIndex = 20;
            this.ResetButton.Text = "Reset";
            this.ResetButton.UseVisualStyleBackColor = true;
            this.ResetButton.Click += new System.EventHandler(this.ResetButton_Click);
            // 
            // PotionButton
            // 
            this.PotionButton.Enabled = false;
            this.PotionButton.Location = new System.Drawing.Point(681, 186);
            this.PotionButton.Name = "PotionButton";
            this.PotionButton.Size = new System.Drawing.Size(115, 75);
            this.PotionButton.TabIndex = 21;
            this.PotionButton.Text = "health potion: 10 gold";
            this.PotionButton.UseVisualStyleBackColor = true;
            this.PotionButton.Click += new System.EventHandler(this.PotionButton_Click);
            // 
            // textBox1
            // 
            this.textBox1.Enabled = false;
            this.textBox1.Location = new System.Drawing.Point(375, 143);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(211, 90);
            this.textBox1.TabIndex = 22;
            this.textBox1.Text = "Zombie: basic monster\r\nSkelleton: double Health\r\nSlime: +3 maximal damage, half h" +
    "ealth\r\n\r\n";
            // 
            // towerButton
            // 
            this.towerButton.Enabled = false;
            this.towerButton.Location = new System.Drawing.Point(681, 267);
            this.towerButton.Name = "towerButton";
            this.towerButton.Size = new System.Drawing.Size(115, 75);
            this.towerButton.TabIndex = 23;
            this.towerButton.Text = "buy tower";
            this.towerButton.UseVisualStyleBackColor = true;
            this.towerButton.Click += new System.EventHandler(this.TowerButton_Click);
            // 
            // TowerCostLabel
            // 
            this.TowerCostLabel.AutoSize = true;
            this.TowerCostLabel.Location = new System.Drawing.Point(681, 349);
            this.TowerCostLabel.Name = "TowerCostLabel";
            this.TowerCostLabel.Size = new System.Drawing.Size(50, 20);
            this.TowerCostLabel.TabIndex = 24;
            this.TowerCostLabel.Text = "Cost: ";
            // 
            // TowerLable
            // 
            this.TowerLable.AutoSize = true;
            this.TowerLable.Location = new System.Drawing.Point(491, 294);
            this.TowerLable.Name = "TowerLable";
            this.TowerLable.Size = new System.Drawing.Size(131, 20);
            this.TowerLable.TabIndex = 25;
            this.TowerLable.Text = "Tower damage: 0";
            // 
            // PauseButton
            // 
            this.PauseButton.Location = new System.Drawing.Point(560, 536);
            this.PauseButton.Name = "PauseButton";
            this.PauseButton.Size = new System.Drawing.Size(115, 75);
            this.PauseButton.TabIndex = 26;
            this.PauseButton.Text = "Pause";
            this.PauseButton.UseVisualStyleBackColor = true;
            this.PauseButton.Visible = false;
            this.PauseButton.Click += new System.EventHandler(this.PauseButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(810, 621);
            this.Controls.Add(this.PauseButton);
            this.Controls.Add(this.TowerLable);
            this.Controls.Add(this.TowerCostLabel);
            this.Controls.Add(this.towerButton);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.PotionButton);
            this.Controls.Add(this.ResetButton);
            this.Controls.Add(this.EXPLabel);
            this.Controls.Add(this.LevelupKnop);
            this.Controls.Add(this.XPLabel);
            this.Controls.Add(this.ExpProgressBar);
            this.Controls.Add(this.CostLabel);
            this.Controls.Add(this.LevelLabel);
            this.Controls.Add(this.GoldLabel);
            this.Controls.Add(this.Monster9);
            this.Controls.Add(this.Monster8);
            this.Controls.Add(this.Monster7);
            this.Controls.Add(this.Monster6);
            this.Controls.Add(this.Monster5);
            this.Controls.Add(this.Monster4);
            this.Controls.Add(this.Monster3);
            this.Controls.Add(this.Monster2);
            this.Controls.Add(this.Monster1);
            this.Controls.Add(this.DamageLabel);
            this.Controls.Add(this.UpgradeKnop);
            this.Controls.Add(this.LifeLabel);
            this.Controls.Add(this.StartKnop);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button StartKnop;
        private System.Windows.Forms.Label LifeLabel;
        private System.Windows.Forms.Button UpgradeKnop;
        private System.Windows.Forms.Label DamageLabel;
        private System.Windows.Forms.Button Monster1;
        private System.Windows.Forms.Button Monster2;
        private System.Windows.Forms.Button Monster3;
        private System.Windows.Forms.Button Monster4;
        private System.Windows.Forms.Button Monster5;
        private System.Windows.Forms.Button Monster6;
        private System.Windows.Forms.Button Monster7;
        private System.Windows.Forms.Button Monster8;
        private System.Windows.Forms.Button Monster9;
        private System.Windows.Forms.Label GoldLabel;
        private System.Windows.Forms.Label LevelLabel;
        private System.Windows.Forms.Label CostLabel;
        private System.Windows.Forms.ProgressBar ExpProgressBar;
        private System.Windows.Forms.Label XPLabel;
        private System.Windows.Forms.Button LevelupKnop;
        private System.Windows.Forms.Label EXPLabel;
        private System.Windows.Forms.Button ResetButton;
        private System.Windows.Forms.Button PotionButton;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button towerButton;
        private System.Windows.Forms.Label TowerCostLabel;
        private System.Windows.Forms.Label TowerLable;
        private System.Windows.Forms.Button PauseButton;
    }
}

