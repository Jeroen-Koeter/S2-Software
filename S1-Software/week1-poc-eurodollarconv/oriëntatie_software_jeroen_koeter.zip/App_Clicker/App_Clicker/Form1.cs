﻿using App_Clicker.Monsters;
using App_Clicker.Monsters.Base;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace App_Clicker
{
    public partial class Form1 : Form
    {
        public List<Monster> monsters = new List<Monster>();
        public Cell[] cells;
        public int Level = 0;
        public int MaxEXP = 50;
        public int Goud = 0;
        public int Prijs = 50;
        public int Playerdamage = 1;
        public int Playerlife = 100;
        public int TowerDamage = 0;
        public int PrijsToren = 30;
        Random Geld = new Random();
        Random Damage = new Random();
        Random Health = new Random();
        Random RandomMonster = new Random();
        private Timer timer1;
        bool inProgress = false;
        bool damageOverTimeBought = false; 

        public Form1()
        {
            InitializeComponent();

            InitTimer();
        }
        private void StartKnop_Click(object sender, EventArgs e)
        {
            inProgress = true;
            monsters = WaveSpawner(9);
            SetButtons();
            SetMonster();
            DisplayWave();
            foreach (var cell in cells)
            {
                cell.CurrentButton.Enabled = true;
            }
            EXPLabel.Text = $"{ExpProgressBar.Value}/{MaxEXP}";
            StartKnop.Enabled = false;
            LevelupKnop.Enabled = false;
            ExpProgressBar.Maximum = MaxEXP;
            CostLabel.Text = $"Upgrade cost: {Prijs}";
            TowerCostLabel.Text = $"Cost: {PrijsToren}";
            PauseButton.Visible = true;
        }

        private void SetMonster()
        {
            for (int i = 0; i < cells.Length; i++)
            {
                if (cells[i].CurrentMonster == null)
                {
                    cells[i].CurrentMonster = monsters[i];
                }
            }
        }

        private void SetButtons()
        {
            cells = new Cell[9];

            for (int i = 0; i < 9; i++)
            {
                cells[i] = new Cell();
            }

            cells[0].CurrentButton = Monster1;
            cells[1].CurrentButton = Monster2;
            cells[2].CurrentButton = Monster3;
            cells[3].CurrentButton = Monster4;
            cells[4].CurrentButton = Monster5;
            cells[5].CurrentButton = Monster6;
            cells[6].CurrentButton = Monster7;
            cells[7].CurrentButton = Monster8;
            cells[8].CurrentButton = Monster9;

        }
        private void DisplayWave()
        {
            foreach (var cell in cells)
            {
                cell.CurrentButton.Text = cell.CurrentMonster.Name + "\n" + cell.CurrentMonster.Health;
            }
        }

        public List<Monster> WaveSpawner(int amountSpawned)
        {
            var result = new List<Monster>();
            for (int i = 0; i < amountSpawned; i++)
            {
                int levens = Health.Next(1, 5);
                int schadeMax = 5 + (6 * Level);
                int schadeMin = 1 + (5 * Level);
                int levensMax = levens + (Level * 3);
                result.Add(GetRandomMonster(schadeMax, schadeMin, levensMax, Level));
            }
            return result;
        }

        private void LevelupKnop_Click(object sender, EventArgs e)
        {
            ExpProgressBar.Value = 0;
            MaxEXP = MaxEXP + 100;
            Playerlife = Playerlife + 100;
            LevelupKnop.Enabled = false;
            ExpProgressBar.Maximum = MaxEXP;
            Level++;
            LevelLabel.Text = $"level: {Level}";
            LifeLabel.Text = $"Life: {Playerlife}";
            EXPLabel.Text = $"{ExpProgressBar.Value}/{MaxEXP}";
        }

        public Monster GetRandomMonster(int schadeMax, int schadeMin, int levensMax, int level)
        {
            int beest = RandomMonster.Next(0, 3);
            Monster result = new Monster("", 1, 1, 1, 1);
            switch (beest)
            {
                case 0:
                    result = new Zombie("Zombie", schadeMax, schadeMin, levensMax, level);
                    break;
                case 1:
                    result = new Skeleton("Skeleton", schadeMax, schadeMin, levensMax *2, level);
                    break;
                case 2:
                    result = new Slime("Slime", schadeMax +3, schadeMin, levensMax/2, level);
                    break;
            }
            return result;
        }

        private void UpgradeKnop_Click(object sender, EventArgs e)
        {
            Goud = Goud - Prijs;
            Prijs = Prijs + 50;
            Playerdamage = Playerdamage + 2 + (Level / 4 * 6);
            DamageLabel.Text = $"Damage: {Playerdamage}";
            GoldLabel.Text = $"Gold: {Goud}";
            CostLabel.Text = $"Upgrade cost: {Prijs}";
            UpgradeKnop.Enabled = false;
            if (Goud < PrijsToren)
            {
                towerButton.Enabled = false;
            }
            if (Goud < 10)
            {
                PotionButton.Enabled = false; 
            }
        }

        private void PlayerAanval(int nummer)
        {
            int money = Geld.Next(1 + (5 * Level), 11 + (11 * Level));
            int Experience = Geld.Next(1 + (2 * Level), 11 + (11 * Level));
            int levens = cells[nummer].CurrentMonster.Health;
            cells[nummer].CurrentMonster.Health = levens - Playerdamage;
            levens -= Playerdamage;
            if (levens > 0)
            {
                cells[nummer].CurrentButton.Text = cells[nummer].CurrentMonster.Name + "\n" + levens;
            }
            else
            {
                cells[nummer].CurrentButton.Text = $"dead {cells[nummer].CurrentMonster.Name}";
                cells[nummer].CurrentButton.Enabled = false;

                ExpProgressBar.Increment(Experience + Level / 2);
                Goud = Goud + (money);
                GoldLabel.Text = $"Gold: {Goud}";

                if (Goud >= Prijs)
                {
                    UpgradeKnop.Enabled = true;
                }
                EXPLabel.Text = $"{ExpProgressBar.Value}/{MaxEXP}";

                if (Goud >= 10)
                {
                    PotionButton.Enabled = true;
                }

                if (Goud >= PrijsToren)
                {
                    towerButton.Enabled = true;
                }
            }

            bool enabled = true;
            int amountOfMonsters = 0;
            foreach (var cell in cells)
            {
                if (cell.CurrentMonster.Health > 0)
                {
                    enabled = false;
                    amountOfMonsters++;
                }
            }

            if (amountOfMonsters == 0)
            {
                inProgress = false;
                PauseButton.Visible = false;
                StartKnop.Enabled = enabled;
                if (ExpProgressBar.Value == MaxEXP)
                {
                    LevelupKnop.Enabled = true;
                }
            }

        }

        public void InitTimer()
        {
            timer1 = new System.Windows.Forms.Timer();
            timer1.Tick += new EventHandler(timer1_Tick);
            timer1.Interval = 2000;
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (inProgress)
            {
                MonsterAanval(0);
                if (damageOverTimeBought == true)
                {
                    TorenAanval(0);
                }
            }
        }

        private void MonsterAanval(int nummer)
        {
            int pijn = Damage.Next(cells[nummer].CurrentMonster.DamageMin, cells[nummer].CurrentMonster.DamageMax);
            foreach (var cell in cells)
            {
                if (cell.CurrentMonster.Health > 0)
                {
                    Playerlife = Playerlife - pijn;
                    LifeLabel.Text = $"Life: {Playerlife}";
                }
            }
            if (Playerlife > 0)
            {
                LifeLabel.Text = $"Life: {Playerlife}";
            }
            else
            {
                inProgress = false;
                ResetButton.Enabled = true;
                MessageBox.Show("you died", "Death");
                PotionButton.Enabled = false;
                Monster1.Enabled = false;
                Monster2.Enabled = false;
                Monster3.Enabled = false;
                Monster4.Enabled = false;
                Monster5.Enabled = false;
                Monster6.Enabled = false;
                Monster7.Enabled = false;
                Monster8.Enabled = false;
                Monster9.Enabled = false;
                UpgradeKnop.Enabled = false;
                PotionButton.Enabled = false;
                StartKnop.Enabled = false;
                LevelupKnop.Enabled = false;
                towerButton.Enabled = false;
                PauseButton.Visible = false;
            }
        }

        private void Monster1_Click(object sender, EventArgs e)
        {
            PlayerAanval(0);
        }

        private void Monster2_Click(object sender, EventArgs e)
        {
            PlayerAanval(1);
        }

        private void Monster3_Click(object sender, EventArgs e)
        {
            PlayerAanval(2);
        }

        private void Monster4_Click(object sender, EventArgs e)
        {
            PlayerAanval(3);
        }

        private void Monster5_Click(object sender, EventArgs e)
        {
            PlayerAanval(4);
        }

        private void Monster6_Click(object sender, EventArgs e)
        {
            PlayerAanval(5);
        }

        private void Monster7_Click(object sender, EventArgs e)
        {
            PlayerAanval(6);
        }

        private void Monster8_Click(object sender, EventArgs e)
        {
            PlayerAanval(7);
        }

        private void Monster9_Click(object sender, EventArgs e)
        {
            PlayerAanval(8);
        }

        private void ResetButton_Click(object sender, EventArgs e)
        {
            Level = 0;
            MaxEXP = 50;
            Goud = 0;
            Prijs = 50;
            Playerdamage = 1;
            Playerlife = 100;
            ExpProgressBar.Value = 0;
            TowerDamage = 0;
            PrijsToren = 30;
            towerButton.Text = "buy tower";
            TowerCostLabel.Text = $"Cost: {PrijsToren}";
            TowerLable.Text = $"Tower damage: {TowerDamage}";
            LifeLabel.Text = $"Life: {Playerlife}";
            DamageLabel.Text = $"Damage: {Playerdamage}";
            GoldLabel.Text = $"Gold: {Goud}";
            CostLabel.Text = $"Upgrade cost: {Prijs}";
            LevelLabel.Text = $"level: {Level}";
            StartKnop.Enabled = true;
            damageOverTimeBought = false;
        }

        private void PotionButton_Click(object sender, EventArgs e)
        {
            Playerlife = Playerlife + 30;
            Goud = Goud - 10;
            GoldLabel.Text = $"Gold: {Goud}";
            EXPLabel.Text = $"{ExpProgressBar.Value}/{MaxEXP}";
            LifeLabel.Text = $"Life: {Playerlife}";
            if (Goud < 10)
            {
                PotionButton.Enabled = false;
            }
            if (Goud < Prijs)
            {
                UpgradeKnop.Enabled = false;
            }
            if (Goud < PrijsToren)
            {
                towerButton.Enabled = false;
            }
        }

        private void TowerButton_Click(object sender, EventArgs e)
        {
            Goud = Goud - PrijsToren;
            TowerDamage += 1;
            PrijsToren += 30;
            TowerLable.Text = $"Tower damage: {TowerDamage}";
            GoldLabel.Text = $"Gold: {Goud}";
            if (Goud < 10)
            {
                PotionButton.Enabled = false;
            }
            if (Goud < Prijs)
            {
                UpgradeKnop.Enabled = false;
            }
            if ( Goud < PrijsToren)
            {
                towerButton.Enabled = false; 
            }
            if (damageOverTimeBought == false)
            {
                towerButton.Text = "upgrade tower";
                damageOverTimeBought = true;
            }
        }
        public void TorenAanval(int nummer)
        {
            int amountOfMonsters = 0;
            foreach (var cell in cells)
            {
                if (cell.CurrentMonster.Health > 0)
                {
                    amountOfMonsters++;
                    cell.CurrentMonster.Health = cell.CurrentMonster.Health - TowerDamage;
                    cell.CurrentButton.Text = cell.CurrentMonster.Name + "\n" + cell.CurrentMonster.Health;
                }
                if (cell.CurrentMonster.Health <= 0)
                {
                    cell.CurrentButton.Text = $"dead {cell.CurrentMonster.Name}";
                    cell.CurrentButton.Enabled = false;
                    if (amountOfMonsters == 0)
                    {
                        inProgress = false;
                        PauseButton.Visible = false;
                        StartKnop.Enabled = true;
                        if (ExpProgressBar.Value == MaxEXP)
                        {
                            LevelupKnop.Enabled = true;
                        }
                    }

                }
            } 
        }

        private void PauseButton_Click(object sender, EventArgs e)
        {
            if (inProgress == true)
            {
                PauseButton.Text = "Resume";
                inProgress = false;
                Monster1.Visible = false;
                Monster2.Visible = false;
                Monster3.Visible = false;
                Monster4.Visible = false;
                Monster5.Visible = false;
                Monster6.Visible = false;
                Monster7.Visible = false;
                Monster8.Visible = false;
                Monster9.Visible = false;
                towerButton.Visible = false;
                PotionButton.Visible = false;
                StartKnop.Visible = false;
                UpgradeKnop.Visible = false;
                LevelupKnop.Visible = false;
            }
            else
            {
                PauseButton.Text = "Pause";
                inProgress = true;
                Monster1.Visible = true;
                Monster2.Visible = true;
                Monster3.Visible = true;
                Monster4.Visible = true;
                Monster5.Visible = true;
                Monster6.Visible = true;
                Monster7.Visible = true;
                Monster8.Visible = true;
                Monster9.Visible = true;
                towerButton.Visible = true;
                PotionButton.Visible = true;
                StartKnop.Visible = true;
                UpgradeKnop.Visible = true;
                LevelupKnop.Visible = true;
            }
        }
    }
}