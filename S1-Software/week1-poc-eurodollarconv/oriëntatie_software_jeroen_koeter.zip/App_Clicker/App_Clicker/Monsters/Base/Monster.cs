﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App_Clicker.Monsters.Base
{
    public class Monster
    {
        public string Name { get; set; }
        public int DamageMax { get; set; }
        public int DamageMin { get; set; }
        public int Health { get; set; }
        public int Experience { get; set; }
        public int Level { get; set; }
        public int Gold { get; set; }

 
        public Monster(string name ,int damageMax, int damageMin, int health, int level)
        {
            this.Name = name;
            this.DamageMax = damageMax;
            this.DamageMin = damageMin;
            this.Health = health;
            this.Level = level;
        }
        
        
    }
}
