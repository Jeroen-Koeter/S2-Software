﻿using App_Clicker.Monsters.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App_Clicker.Monsters
{
    public class Slime : Monster
    {
        public Slime(string name, int damageMax, int damageMin, int health, int level) 
            : base(name, damageMax, damageMin, health, level)
        {
        }
    }
}

