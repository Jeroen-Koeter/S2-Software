﻿using App_Clicker.Monsters.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace App_Clicker.Monsters
{
    public class Cell
    {
        public Button CurrentButton { get; set; }
        public Monster CurrentMonster { get; set; }
    }
}
