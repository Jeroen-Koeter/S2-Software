﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GameHub
{
    public partial class Form1 : Form
    {
        private const string nameInvaderLeft = "invaderLeft";
        private const string nameInvaderRight = "invaderRight";
        private const string nameBullet = "bullet";
        bool goleft;
        bool goright;
        int speed = 5;
        int score = 0;
        bool isPressed;
        int totalEnemies = 12;
        int playerSpeed = 6;
        public Form1()
        {
            InitializeComponent();
            Alien.
        }

        private void keyisdown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left)
            {
                goleft = true;
            }
            if (e.KeyCode == Keys.Right)
            {
                goright = true;
            }
            if (e.KeyCode == Keys.Space && !isPressed)
            {
                isPressed = true;
                MakeBullet();
            }
        }

        private void keyisup(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left)
            {
                goleft = false;
            }
            if (e.KeyCode == Keys.Right)
            {
                goright = false;
            }
            if(isPressed)
            {
                isPressed = false;
            }
        }

        private void Timer1_Tick(object sender, EventArgs e)
        {
            // player movement:
            if (goleft)
            {
                if (player.Left > 0)
                {
                    player.Left -= playerSpeed;
                }
                else
                {
                    player.Left = 0;
                }
            }
            if (goright)
            {
                if (player.Left < 425)
                {
                    player.Left += playerSpeed;
                }
                else
                {
                    player.Left = 425;
                }
            }
            // invader movement:
            foreach (Control x  in this.Controls)
            {
                if (x is PictureBox && (x.Tag == nameInvaderLeft || x.Tag == nameInvaderRight))
                {
                    PictureBox a = (PictureBox)x;
                    if (a.Bounds.IntersectsWith(player.Bounds))
                    {
                        GameOver();
                    }
                    if (a.Tag == nameInvaderLeft)
                    {
                        a.Left += speed;
                    }
                    if (a.Tag == nameInvaderRight)
                    {
                        a.Left -= speed;
                    }
                    if (a.Left > (450 - a.Size.Width))
                    {
                        a.Top += a.Height + 10;
                        a.Tag = nameInvaderRight;
                    }
                    if (a.Left <= 0)
                    {
                        a.Top += a.Height + 10;
                        a.Tag = nameInvaderLeft;
                    }
                }
            }
            // bullet movement:
            foreach (Control y in this.Controls)
            {
                if (y is PictureBox && y.Tag == nameBullet)
                {
                    y.Top -= 20;
                    if (((PictureBox)y).Top < this.Height - 490)
                    {
                        this.Controls.Remove(y);
                    }
                }
            }
            // bullet alien collision:
            foreach (Control i in this.Controls)
            {
                foreach (Control j in this.Controls)
                {
                    if (i is PictureBox && (i.Tag == nameInvaderLeft || i.Tag ==nameInvaderRight))
                    {
                        if (j is PictureBox && j.Tag == nameBullet)
                        {
                            if (i.Bounds.IntersectsWith(j.Bounds))
                            {
                                score++;
                                this.Controls.Remove(i);
                                this.Controls.Remove(j);
                            }
                        }
                    }
                }
            }
            // updating label:
            label1.Text = "Score : " + score;
            if (score > totalEnemies - 1)
            {
                GameOver();
                label1.Text = "You Win!!!!";
            }
        }
        private void MakeBullet()
        {
            PictureBox bullet = new PictureBox();
            bullet.Image = Properties.Resources.bullet1;
            bullet.Size = new Size(5, 20);
            bullet.Tag = "bullet";
            bullet.Left = player.Left + player.Width / 2;
            bullet.Top = player.Top - 20;
            bullet.SizeMode = PictureBoxSizeMode.StretchImage;
            this.Controls.Add(bullet);
            bullet.BringToFront();
        }

        private void GameOver()
        {
            label1.Text = " Game Over";
            SpawnResetButton();
            timer1.Stop();
        }

        private void SpawnResetButton()
        {
            Button resetButton = new Button();
            resetButton.Text = "Reset";
            resetButton.Width = 100;
            resetButton.Height = 75;
            resetButton.Location = new Point(175, 20);
            Controls.Add(resetButton);
        }
    }
}