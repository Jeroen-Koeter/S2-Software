﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace GameHub
{
    class Alien : GameObject
    {
        private int alien_picture = 1;
        public Alien(int speed, string tag) : base(speed, tag)
        {
            speed = 5;
            tag = "";
        }

        public override PictureBox BuildFullPictureBox()
        {
            int x = 622;
            int y = 12
            for (int i = 0; i < 12; i++)
            {
                PictureBox alien = BuildPictureBox();
                alien.Image = ImageSelect();
                alien.Location = new Point (x, y);
                x -= 56;
            }
            return; 
            
        }
        public void ImageSelect()
        {
            switch (alien_picture)
            {
                case 1:
                  var Pic1 = Properties.Resources.alien_1;
                break;

            }
        }
    }
}
